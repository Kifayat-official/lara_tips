<div class="text-right">
    <button type="submit" class="btn btn-sm btn-primary">
        <i class="fa fa-save"></i>
        Save
    </button>
</div>