<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Webpatser\Uuid\Uuid;

class TestProfileMandatoryColumn extends CommonUuidModel
{
    
}
